class Artifact(object):
    pass
