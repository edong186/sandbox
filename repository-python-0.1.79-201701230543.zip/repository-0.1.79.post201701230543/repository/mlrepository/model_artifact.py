from artifact import Artifact


class ModelArtifact(Artifact):
    def reader(self):
        from repository.mlrepositoryclient import ContentReader

        try:
            return self._reader
        except:
            if self._content_href is not None:
                self._reader = ContentReader(self._content_href,
                                                  self.client.repository_api)
            else:
                self._reader = None
            return self._reader

    def pipeline_artifact(self):
        try:
            return self._pipeline_artifact
        except:
            self._pipeline_artifact = self.client.pipelines.version_from_href(self._pipeline_version_href)
            return self._pipeline_artifact

