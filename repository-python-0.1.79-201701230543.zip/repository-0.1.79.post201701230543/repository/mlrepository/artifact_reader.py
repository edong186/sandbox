class ArtifactReader(object):
    pass
