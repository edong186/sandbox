from artifact import Artifact


class PipelineArtifact(Artifact):
    def reader(self):
        from repository.mlrepositoryclient import ContentReader
        try:
            return self._reader
        except:
            if self._content_href is not None:
                self._reader = ContentReader(self._content_href, self.repository_api)
            else:
                self._reader = None

            return self._reader
