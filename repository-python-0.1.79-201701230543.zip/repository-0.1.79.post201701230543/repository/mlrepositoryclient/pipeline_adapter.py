import re
from repository.mlrepository import MetaNames, MetaProps, PipelineArtifact
from repository.mlrepositoryartifact import SparkPipelineLoader, SparkPipelineContentLoader,\
    IBMSparkPipelineContentLoader
from repository.util import Json2ObjectMapper


class PipelineAdapter(object):
    def __init__(self, pipeline_output, version_output, repository_api):
        self.pipeline_output = pipeline_output
        self.version_output = version_output
        self.repository_api = repository_api
        self.pipeline_type = pipeline_output.entity.type

    def artifact(self):
        if re.match('sparkml-pipeline-\d+\.\d+', self.pipeline_type) is not None:
            pipeline_artifact_builder = type(
                "PipelineArtifact",
                (SparkPipelineContentLoader, SparkPipelineLoader, PipelineArtifact, object),
                {}
            )
        elif re.match('ibm-sparkml-pipeline-\d+\.\d+', self.pipeline_type) is not None:
            pipeline_artifact_builder = type(
                "IBMPipelineArtifact",
                (IBMSparkPipelineContentLoader, SparkPipelineLoader, PipelineArtifact, object),
                {}
            )
        else:
            raise ValueError('Invalid pipeline_type: {}'.format(self.pipeline_type))

        pipeline_artifact = pipeline_artifact_builder()
        pipeline_artifact.uid = self.pipeline_output.metadata.guid
        pipeline_artifact.name = self.pipeline_output.entity.name
        pipeline_artifact.repository_api = self.repository_api

        prop_map = {
            MetaNames.CREATION_TIME: self.pipeline_output.metadata.created_at,
            MetaNames.LAST_UPDATED: self.pipeline_output.metadata.modified_at,
            MetaNames.PIPELINE_TYPE: self.pipeline_output.entity.type,
            MetaNames.RUNTIME: self.pipeline_output.entity.runtime_environment,
        }

        if self.pipeline_output.entity.description is not None:
            prop_map[MetaNames.DESCRIPTION] = self.pipeline_output.entity.description

        if self.pipeline_output.entity.author is not None:
            prop_map[MetaNames.AUTHOR] = Json2ObjectMapper.to_object(self.pipeline_output.entity.author)

        pipeline_artifact.meta = MetaProps(prop_map)

        if self.version_output is not None:
            version_prop_map = {
                MetaNames.VERSION: self.version_output.metadata.guid,
                MetaNames.PIPELINE_VERSION_HREF: self.version_output.metadata.href
            }

            if self.version_output.entity.label_col is not None:
                version_prop_map[MetaNames.LABEL_FIELD] = self.version_output.entity.label_col

            pipeline_artifact.meta.merge(MetaProps(version_prop_map))

            pipeline_artifact._content_href = self.version_output.entity.content_href

        else:
            pipeline_artifact._content_href = None

        return pipeline_artifact
