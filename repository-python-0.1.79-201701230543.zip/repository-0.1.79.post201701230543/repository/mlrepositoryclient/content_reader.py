from repository.mlrepository import ArtifactReader


class ContentReader(ArtifactReader):
    def __init__(self, content_href, repository_api):
        self.content_href = content_href
        self.repository_api = repository_api
        # val apiInvoker: ApiInvoker = repositoryApi.apiInvoker
        # val basePath: String = repositoryApi.basePath
        # var entity: Option[InputStream] = None

    def read(self):
        self.close()
        return self._download()

    def close(self):  # TODO ????
        # entity.map(is => is.close())
        pass

    def _download(self):
        return self.repository_api.download_artifact_content(self.content_href)