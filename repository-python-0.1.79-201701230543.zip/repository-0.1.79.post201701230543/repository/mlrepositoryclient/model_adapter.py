import re
from repository.mlrepository import MetaNames, MetaProps, ModelArtifact
from repository.mlrepositoryartifact import SparkPipelineModelLoader, SparkPipelineModelContentLoader,\
    IBMSparkPipelineModelContentLoader
from repository.util import Json2ObjectMapper


class ModelAdapter(object):
    def __init__(self, model_output, model_version_output, client):
        self.model_output = model_output
        self.model_version_output = model_version_output
        self.client = client
        self.model_type = model_output.entity.type

    def artifact(self):
        if re.match('sparkml-model-\\d+\\.\\d+', self.model_type) is not None:
            model_artifact_builder = type(
                "ModelArtifact",
                (SparkPipelineModelContentLoader, SparkPipelineModelLoader, ModelArtifact, object),
                {}
            )
        elif re.match('ibm-sparkml-model-\d+\.\d+', self.model_type) is not None:
            model_artifact_builder = type(
                "IBMModelArtifact",
                (IBMSparkPipelineModelContentLoader, SparkPipelineModelLoader, ModelArtifact, object),
                {}
            )
        else:
            raise ValueError('Invalid model_type: {}'.format(self.model_type))

        model_artifact = model_artifact_builder()
        model_artifact.uid = self.model_output.metadata.guid
        model_artifact.name = self.model_output.entity.name
        model_artifact._pipeline_version_href = self.model_output.entity.pipeline_version.href
        model_artifact.client = self.client

        prop_map = {
            MetaNames.CREATION_TIME: self.model_output.metadata.created_at,
            MetaNames.LAST_UPDATED: self.model_output.metadata.modified_at,
            MetaNames.MODEL_TYPE: self.model_output.entity.type,
            MetaNames.RUNTIME: self.model_output.entity.runtime_environment
        }

        if self.model_output.entity.description is not None:
            prop_map[MetaNames.DESCRIPTION] = self.model_output.entity.description

        if self.model_output.entity.label_col is not None:
            prop_map[MetaNames.LABEL_FIELD] = self.model_output.entity.label_col

        if self.model_output.entity.author is not None:
            prop_map[MetaNames.AUTHOR] = Json2ObjectMapper.read(self.model_output.entity.author)

        model_artifact.meta = MetaProps(prop_map)

        if self.model_version_output is not None:
            version_props = MetaProps({
                MetaNames.VERSION: self.model_version_output.metadata.guid,
                MetaNames.MODEL_VERSION_HREF: self.model_version_output.metadata.href
            })

            training_data = self.model_version_output.entity.training_data
            if training_data is not None:
                training_props = MetaProps({
                    MetaNames.TRAINING_DATA_REF: training_data.connection,
                    MetaNames.TRAINING_DATA_SCHEMA: training_data.schema
                })
                version_props.merge(training_props)

            model_artifact.meta.merge(version_props)

            model_artifact._content_href = self.model_version_output.entity.content_href

        else:
            model_artifact._content_href = None

        return model_artifact
