from pyspark.ml import Pipeline, PipelineModel


class SparkUtil(object):
    @staticmethod
    def get_label_col(spark_artifact):
        if isinstance(spark_artifact, PipelineModel):
            pipeline = Pipeline(stages=spark_artifact.stages)
            return SparkUtil.get_model_label_col_by_stages(pipeline.getStages())
        elif isinstance(spark_artifact, Pipeline):
            return SparkUtil.get_pipeline_label_col_by_stages(spark_artifact.getStages())
        else:
            raise ValueError('Artifact is not Pipeline nor PipelineModel')

    @staticmethod
    def get_pipeline_label_col_by_stages(stages):
        try:
            label_col = stages[-1].getLabelCol()
        except Exception as ex:
            label_col = 'label'

        reversed_stages = stages[:]
        reversed_stages.reverse()

        for stage in reversed_stages[1:]:
            try:
                if stage.getOutputCol() == label_col:
                    label_col = stage.getInputCol()
            except Exception as ex:
                pass

        return label_col

    @staticmethod
    def get_model_label_col_by_stages(stages):
        try:
            label_col = stages[-1]._call_java("getLabelCol")
        except Exception as ex:
            label_col = 'label'

        reversed_stages = stages[:]
        reversed_stages.reverse()

        for stage in reversed_stages[1:]:
            try:
                if stage._call_java("getOutputCol") == label_col:
                    label_col = stage._call_java("getInputCol")
            except Exception as ex:
                pass

        return label_col
