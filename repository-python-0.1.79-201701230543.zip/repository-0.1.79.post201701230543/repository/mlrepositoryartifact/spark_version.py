from pyspark.ml import Pipeline
from pyspark import SparkContext, SparkConf


class SparkVersion(object):
    @staticmethod
    def significant():
        conf = SparkConf()
        sc = SparkContext.getOrCreate(conf=conf)
        version_parts = [int(version_part) for version_part in sc.version.split('.')]
        return "{}.{}".format(version_parts[0], version_parts[1])