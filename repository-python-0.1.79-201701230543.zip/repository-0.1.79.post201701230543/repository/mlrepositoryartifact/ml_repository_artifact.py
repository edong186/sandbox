from spark_pipeline_model_artifact import SparkPipelineModelArtifact
from spark_pipeline_artifact import SparkPipelineArtifact
from repository.mlrepository.meta_props import MetaProps

from pyspark.ml.pipeline import Pipeline, PipelineModel
from pyspark.sql import DataFrame


def MLRepositoryArtifact(spark_artifact, training_data=None, name=None, meta_props=MetaProps({})):
    """
    Returns SparkPipelineModelArtifact or SparkPipelineArtifact depending on params.

    Except first param (spark_artifact) all other params should be named or in right order.

    :param spark_artifact: pyspark.ml.Pipeline or pyspark.ml.PipelineModel which will be wrapped
    :param DataFrame training_data: training data, not used for pipeline, mandatory for pipeline model
    :param str name: name for artifact
    :param MetaProps meta_props: props used by other services
    :return: artifact required by MLRepositoryClient
    :rtype: SparkPipelineArtifact or SparkPipelineModelArtifact
    """
    if isinstance(meta_props, dict):
        meta_props = MetaProps(meta_props.copy())

    if name is not None and not isinstance(name, str):
        raise ValueError('Invalid type for name: {}'.format(name.__class__.__name__))

    if training_data is not None and not isinstance(training_data, DataFrame):
        raise ValueError('Invalid type for training_data: {}'.format(training_data.__class__.__name__))

    if not isinstance(meta_props, MetaProps):
        raise ValueError('Invalid type for meta_props: {}'.format(meta_props.__class__.__name__))

    if spark_artifact is not None and (isinstance(spark_artifact, Pipeline) or issubclass(spark_artifact, Pipeline)):
        return _get_pipeline(spark_artifact, name=name, meta_props=meta_props)
    elif spark_artifact is not None and training_data is not None and (isinstance(spark_artifact, PipelineModel) or issubclass(spark_artifact, PipelineModel)):
        return _get_pipeline_model(spark_artifact, training_data=training_data, name=name, meta_props=meta_props)
    else:
        raise ValueError('Invalid arguments.')

def _get_pipeline(pipeline, name, meta_props):
    return SparkPipelineArtifact(pipeline, name=name, meta_props=meta_props)

def _get_pipeline_model(pipeline_model, training_data, name, meta_props):
    return SparkPipelineModelArtifact(pipeline_model, training_data=training_data, name=name, meta_props=meta_props)
