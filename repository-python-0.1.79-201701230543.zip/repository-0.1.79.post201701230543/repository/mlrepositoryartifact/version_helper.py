import re
from spark_version import SparkVersion


class VersionHelper(object):
    @staticmethod
    def significant(a):  # unable to use method from scala
        return SparkVersion.significant()

    @staticmethod
    def pipeline_type(ml_pipeline):
        version = VersionHelper.significant(ml_pipeline)
        canonical_name = ml_pipeline.__class__.__name__
        if canonical_name == 'Pipeline':
            return 'sparkml-pipeline-{}'.format(version)
        elif canonical_name == 'IBMSparkPipeline':
            return 'ibm-sparkml-pipeline-1.0'
        else:
            raise ValueError('Unsupported Pipeline class: {}'.format(canonical_name))

    @staticmethod
    def model_type(ml_pipeline_model):
        version = VersionHelper.significant(ml_pipeline_model)
        class_name = ml_pipeline_model.__class__.__name__
        if class_name == 'PipelineModel':
            return 'sparkml-model-{}'.format(version)
        elif class_name == 'IBMSparkPipelineModel':
            return 'ibm-sparkml-model-1.0'
        else:
            raise ValueError('Unsupported PipelineModel class: {}'.format(class_name))