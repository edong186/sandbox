from spark_pipeline_reader import SparkPipelineReader
from repository.mlrepository import MetaNames, MetaProps, PipelineArtifact
from repository.util import SparkUtil
from spark_version import SparkVersion
from version_helper import VersionHelper
from pyspark.ml import Pipeline


class SparkPipelineArtifact(PipelineArtifact):
    """
    Class of pipeline artifacts created with MLRepositoryCLient.

    :param pyspark.ml.Pipeline ml_pipeline: Pipeline which will be wrapped
    :param str uid: optional, uid which indicate that artifact with this Pipeline already exists in repository service
    :param str name: optional, name of artifact
    :param MetaProps meta_props: optional, props used by other services

    :ivar pyspark.ml.Pipeline ml_pipeline: Pipeline associated with this artifact
    :ivar str uid: uid of this artifact, not None means that with this artifact is associated entry in repository service
    :ivar str name: name for artifact
    :ivar MetaProps meta: props used by other services
    """
    def __init__(self, ml_pipeline, uid=None, name=None, meta_props=MetaProps({})):
        super(SparkPipelineArtifact, self).__init__()

        if not issubclass(type(ml_pipeline), Pipeline):
            raise ValueError('Invalid type for ml_pipeline: {}'.format(ml_pipeline.__class__.__name__))

        if uid is not None and not isinstance(uid, str):
            raise ValueError('Invalid type for uid: {}'.format(uid.__class__.__name__))

        if name is not None and not isinstance(name, str):
            raise ValueError('Invalid type for name: {}'.format(name.__class__.__name__))

        if not isinstance(meta_props, MetaProps):
            raise ValueError('Invalid type for meta_props: {}'.format(meta_props.__class__.__name__))

        self.uid = uid
        self.name = name
        self.ml_pipeline = ml_pipeline
        self.meta = meta_props
        self.meta.merge(
            MetaProps({
                MetaNames.RUNTIME: 'spark-{}'.format(SparkVersion.significant()),
                MetaNames.PIPELINE_TYPE: VersionHelper.pipeline_type(ml_pipeline),
                MetaNames.LABEL_FIELD: SparkUtil.get_label_col(ml_pipeline)
            })
        )

    def reader(self):
        """
        Returns reader used for getting pipeline content.

        :return: reader for pyspark.ml.Pipeline
        :rtype: SparkPipelineReader
        """
        try:
            return self._reader
        except:
            self._reader = SparkPipelineReader(self.ml_pipeline, 'pipeline')
            return self._reader

    def copy(self, uid):
        return SparkPipelineArtifact(self.ml_pipeline, uid, self.name, self.meta)
