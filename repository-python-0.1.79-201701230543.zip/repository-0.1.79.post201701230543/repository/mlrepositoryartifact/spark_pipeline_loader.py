from spark_artifact_loader import SparkArtifactLoader


class SparkPipelineLoader(SparkArtifactLoader):
    def pipeline_instance(self):
        return self.load()
