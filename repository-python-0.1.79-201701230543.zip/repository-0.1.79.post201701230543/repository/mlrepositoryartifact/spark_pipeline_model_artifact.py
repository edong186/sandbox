from spark_pipeline_reader import SparkPipelineReader
from pyspark.ml.pipeline import Pipeline, PipelineModel
from pyspark.sql import DataFrame
from repository.mlrepository import MetaNames, MetaProps, ModelArtifact
from repository.util.spark_util import SparkUtil
from spark_version import SparkVersion
from version_helper import VersionHelper


class SparkPipelineModelArtifact(ModelArtifact):
    """
    Class of model artifacts created with MLRepositoryCLient.

    :param pyspark.ml.PipelineModel ml_pipeline_model: Pipeline Model which will be wrapped
    :param DataFrame training_data: training_data compatible with Pipeline Model
    :param str uid: optional, uid which indicate that artifact with this Pipeline Model already exists in repository service
    :param str name: optional, name of artifact
    :param SparkPipelineArtifact pipeline_artifact: optional, pipeline artifact which Pipeline was used to generate Pipeline Model for this artifact
    :param MetaProps meta_props: optional, props used by other services

    :ivar pyspark.ml.PipelineModel ml_pipeline_model: Pipeline Model associated with this artifact
    :ivar DataFrame training_data: training_data compatible with Pipeline Model of this artifact
    :ivar str uid: uid of this artifact, not None means that with this artifact is associated entry in repository service
    :ivar str name: name for artifact
    :ivar MetaProps meta: props used by other services
    """
    def __init__(self, ml_pipeline_model, training_data, uid=None, name=None, pipeline_artifact=None, meta_props=MetaProps({})):
        super(SparkPipelineModelArtifact, self).__init__()

        if not issubclass(type(ml_pipeline_model), PipelineModel):
            raise ValueError('Invalid type for ml_pipeline: {}'.format(ml_pipeline_model.__class__.__name__))

        if not isinstance(training_data, DataFrame):
            raise ValueError('Invalid type for training_data: {}'.format(training_data.__class__.__name__))

        if uid is not None and not isinstance(uid, str):
            raise ValueError('Invalid type for uid: {}'.format(uid.__class__.__name__))

        if name is not None and not isinstance(name, str):
            raise ValueError('Invalid type for name: {}'.format(name.__class__.__name__))

        if not isinstance(meta_props, MetaProps):
            raise ValueError('Invalid type for meta_props: {}'.format(meta_props.__class__.__name__))

        self.ml_pipeline_model = ml_pipeline_model
        self.training_data = training_data
        self.uid = uid
        self.name = name
        self._pipeline_artifact = pipeline_artifact
        self.ml_pipeline = Pipeline(stages=ml_pipeline_model.stages)

        # meta
        self.meta = meta_props
        self.meta.merge(
            MetaProps({
                MetaNames.RUNTIME: 'spark-{}'.format(SparkVersion.significant()),
                MetaNames.PIPELINE_TYPE: VersionHelper.pipeline_type(self.ml_pipeline),
                MetaNames.MODEL_TYPE: VersionHelper.model_type(ml_pipeline_model),
                # MetaNames.TRAINING_DATA_REF: '{}',
                MetaNames.TRAINING_DATA_SCHEMA: self.training_data.schema.json(),
                MetaNames.LABEL_FIELD: SparkUtil.get_label_col(ml_pipeline_model)
            })
        )

    def pipeline_artifact(self):
        """
        Returns Pipeline artifact associated with this model artifact.

        If pipeline artifact was provided by user during creation - it will be returned. Otherwise will be created new pipeline artifact and returned.

        :return: Pipeline artifact associated with this Model artifact
        :rtype: SparkPipelineArtifact
        """
        if self._pipeline_artifact is None:
            from ml_repository_artifact import MLRepositoryArtifact
            self._pipeline_artifact = MLRepositoryArtifact(self.ml_pipeline, name=None)

        return self._pipeline_artifact

    def reader(self):
        """
        Returns reader used for getting pipeline model content.

        :return: reader for pyspark.ml.PipelineModel
        :rtype: SparkPipelineReader
        """
        try:
            return self._reader
        except:
            self._reader = SparkPipelineReader(self.ml_pipeline_model, 'model')
            return self._reader

    def copy(self, uid=None, pipeline_artifact=None, meta_props=None):
        if uid is None:
            uid = self.uid

        if pipeline_artifact is None:
            pipeline_artifact = self.pipeline_artifact

        if meta_props is None:
            meta_props = self.meta

        return SparkPipelineModelArtifact(
            self.ml_pipeline_model,
            training_data=self.training_data,
            uid=uid,
            name=self.name,
            pipeline_artifact=pipeline_artifact,
            meta_props=meta_props
        )
