from pyspark.ml import Pipeline, PipelineModel


class SparkPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        return Pipeline.read().load(content_dir)


class IBMSparkPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from pipeline import IBMSparkPipeline
        return IBMSparkPipeline.read().load(content_dir)


class SparkPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        return PipelineModel.read().load(content_dir)


class IBMSparkPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from pipeline import IBMSparkPipelineModel
        print IBMSparkPipelineModel
        print IBMSparkPipelineModel.read()
        return IBMSparkPipelineModel.read().load(content_dir)