from spark_artifact_loader import SparkArtifactLoader


class SparkPipelineModelLoader(SparkArtifactLoader):
    def model_instance(self):
        return self.load()